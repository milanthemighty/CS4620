//PA2Test1
//Explores all aspects of PA2 Grammar: Import statements, main class, and the setPixel function.

import meggy.Meggy;

class PA2Test1 {
       public static void main(String[] whatever){
               Meggy.setPixel( (byte)1, (byte)1, Meggy.Color.RED );
        }
}
