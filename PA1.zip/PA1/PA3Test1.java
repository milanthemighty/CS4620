//PA3Test1.java
//Tests the following three features: 
// 1. setPixel()
// 2. delay()
// 3. if-statement

import meggy.Meggy;

class PA3Test1 {
	public static void main(String[] whatever){
		Meggy.setPixel( (byte)1, (byte)1, Meggy.Color.RED);
		Meggy.delay(1000);
		while (true) {
			if (Meggy.checkButton(Meggy.Button.A))
				Meggy.setPixel((byte)1, (byte)1, Meggy.Color.BLUE);
			else
				Meggy.setPixel( (byte)1, (byte)1, Meggy.Color.RED);
			Meggy.delay(100);	
		}
        }
}
