//PA3Test2.java
//Tests the following three features: 
// 1. while-loop
// 2. getPixel()
// 3. checkButton

import meggy.Meggy;

class PA3Test2 {
	public static void main(String[] whatever){
		Meggy.setPixel( (byte)1, (byte)1, Meggy.Color.RED);
		Meggy.delay(1000);
		while (true) {
			if (Meggy.checkButton(Meggy.Button.A))
				Meggy.setPixel((byte)1, (byte)1, Meggy.Color.GREEN);
			Meggy.delay(1000);
			if (Meggy.getPixel((byte)1, (byte)1) == Meggy.Color.GREEN)
				Meggy.setPixel((byte)1, (byte)1, Meggy.Color.RED);	
		}
        }
}
