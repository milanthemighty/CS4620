//PA3Test3.java
//Tests the following three features: 
// 1. Equivalence
// 2. Not (!)
// 3. <Button_Literal>

import meggy.Meggy;

class PA3Test3 {
	public static void main(String[] whatever){
		Meggy.setPixel((byte)1, (byte)1, Meggy.Color.RED);
		Meggy.setPixel((byte)1, (byte)2, Meggy.Color.GREEN);

		if (!(Meggy.getPixel((byte)1, (byte)1) == Meggy.getPixel((byte)1, (byte)2)))
			Meggy.setPixel((byte)1, (byte)3, Meggy.Color.BLUE);
		if (Meggy.checkButton(Meggy.Button.A) == Meggy.checkButton(Meggy.Button.B))
			Meggy.setPixel((byte)1, (byte)4, Meggy.Color.YELLOW);
        }
}
