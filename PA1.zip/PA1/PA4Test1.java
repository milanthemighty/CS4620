//PA4Test1.java
//Tests the following three features: 
// 1. Function Definition
// 2. Function Call
// 3. Passing Parameters

import meggy.Meggy;

class PA4Test1 {	
	public static void main(String[] whatever){
		new colorChanger().changeRedRow(1, 1);
        }
}

class colorChanger {

	public void colorChanger() {	
	}

	public void changeRedRow(int x, int y) {
		Meggy.setPixel((byte)x, (byte)y, Meggy.Color.RED);
	}
}
