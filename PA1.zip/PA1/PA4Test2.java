//PA4Test2.java
//Tests the following three features: 
// 1. Less Than
// 2. Return
// 3. toneStart()

import meggy.Meggy;

class PA4Test2 {
	public static void main(String[] whatever){
		if (12 < 13)
			Meggy.toneStart(Meggy.Tone.Cs3, 4000);
		new ret().testReturn();
        }
}

class ret {

	public void ret() {	
	}

	public int testReturn() {
		return 1; 
	}
}
