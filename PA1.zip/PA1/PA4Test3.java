//PA4Test3.java
//Tests the following three features: 
// 1. this
// 2. new Class
// 3. passing int -> byte

import meggy.Meggy;

class PA4Test3 {
	public static void main(String[] whatever){
		new colorChanger().changeRedRow((byte)3, (byte)3);
        }
}

class colorChanger {

	public void colorChanger() {	
	}

	public void changeRedRow(int x, int y) {
		Meggy.setPixel((byte)x, (byte)y, Meggy.Color.RED);
		this.testThis();	
	}
	public void testThis() {

	}
}


