//PA5Test1.java
//Tests the following three features: 
// 1. Color Variable Declaration
// 2. Button Variable Declaration
// 3. Tone Variable Declaration


import meggy.Meggy;

class PA5Test1 {
	public static void main(String[] whatever){
		new Tester().test();
        }
}

class Tester { 
	Meggy.Color color; 
	Meggy.Button button; 
	Meggy.Tone tone; 
	public void test() {
		color = Meggy.Color.RED;
		button = Meggy.Button.A;
		tone = Meggy.Tone.Cs3; 
		while (true) {
			if (Meggy.checkButton(button)) {
				Meggy.setPixel((byte)1, (byte)1, color);
				Meggy.toneStart(tone, 1000);
			}
		} 
	}
}
