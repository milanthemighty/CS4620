//PA5Test2.java
//Tests the following three features: 
// 1. Object Creation
// 2. Local Assignment Statements
// 3. More Assignment Statements


import meggy.Meggy;

class PA5Test2 {
	public static void main(String[] whatever){
		new Tester().test();
        }
}

class Tester { 
	public void test() {
		Meggy.Color color;
		Meggy.Tone tone;
		color = Meggy.Color.GREEN;
		tone = Meggy.Tone.Cs3;
		Meggy.setPixel((byte)1, (byte)1, color);
		Meggy.toneStart(tone, 1000);
	}
}
