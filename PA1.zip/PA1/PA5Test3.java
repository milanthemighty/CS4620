//PA5Test3.java
//Tests the following three features: 
// 1. Byte Type Expression to Int
// 2. General Variable Declaration
// 3. More Variable Declaration


import meggy.Meggy;

class PA5Test3 {
	public static void main(String[] whatever){
		new Tester().test();
        }
}

class Tester { 
	int variable1;
	int variable2;
	int variable3;
	int variable4; 
	public void test() {
		variable1 = 1;
		variable2 = (byte)1;
		variable3 = (3 + 3);
		while(true) { 		
			if (Meggy.checkButton(Meggy.Button.A))
				variable4 = 26;	
			Meggy.delay(1000); 
		}	
	}
}

