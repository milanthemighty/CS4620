import meggy.Meggy;

class LessThanTest {
    public static void main(String[] whatever){
	if (1 < 2)
		Meggy.toneStart(Meggy.Tone.C3, 500);
    }
}




