import meggy.Meggy;

class ToneTest {
    public static void main(String[] whatever){
	Meggy.toneStart(Meggy.Tone.C3, 500);
    }
}




