import meggy.Meggy;

class TypeError {
 
    public static void main(String[] whatever){
	new B().setP((byte)3,(byte)7,Meggy.Color.BLUE);
    }
}

class C {
    public void setP(byte x, byte y, Meggy.Color c) {
            Meggy.setPixel(x, x, c);    
    }
}

class B {

}




