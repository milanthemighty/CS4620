package ast_visitors;

import ast.node.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;

import symtable.SymTable;
import symtable.Type;
import symtable.STE;
import symtable.ClassSTE;
import symtable.MethodSTE;
import symtable.Signature;
import exceptions.InternalException;
import exceptions.SemanticException;

public class CheckTypes extends DepthFirstVisitor
{
    
   private SymTable mCurrentST;
   private ClassSTE mCurrentClass;
   
   public CheckTypes(SymTable st) {
     if(st==null) {
          throw new InternalException("unexpected null argument");
      }
      mCurrentST = st;
   }

   public void defaultOut(Node node) {
       System.err.println("Node not implemented in CheckTypes, " + node.getClass());
   }
   
   public void outAndExp(AndExp node)
   {
     if(this.mCurrentST.getExpType(node.getLExp()) != Type.BOOL) {
       throw new SemanticException("Invalid left operand type for operator &&", node.getLExp().getLine(), node.getLExp().getPos());
     }

     if(this.mCurrentST.getExpType(node.getRExp()) != Type.BOOL) {
       throw new SemanticException("Invalid right operand type for operator &&", node.getRExp().getLine(), node.getRExp().getPos());
     }

     this.mCurrentST.setExpType(node, Type.BOOL);
   }
  
   public void outPlusExp(PlusExp node)
   {
       Type lexpType = this.mCurrentST.getExpType(node.getLExp());
       Type rexpType = this.mCurrentST.getExpType(node.getRExp());
       if ((lexpType==Type.INT  || lexpType==Type.BYTE) && (rexpType==Type.INT  || rexpType==Type.BYTE)){
           this.mCurrentST.setExpType(node, Type.INT);
       } else {
           throw new SemanticException("Operands to + operator must be INT or BYTE", node.getLExp().getLine(),node.getLExp().getPos());
       }
   }
    
    public void outMulExp(MulExp node)
    {
        Type lexpType = this.mCurrentST.getExpType(node.getLExp());
        Type rexpType = this.mCurrentST.getExpType(node.getRExp());
        if ((lexpType==Type.INT  || lexpType==Type.BYTE) && (rexpType==Type.INT  || rexpType==Type.BYTE)){
            this.mCurrentST.setExpType(node, Type.INT);
        } else {
            throw new SemanticException("Operands to * operator must be INT or BYTE", node.getLExp().getLine(), node.getLExp().getPos());
        }
    }
    
    public void outMinusExp(MinusExp node){
        Type lexpType = this.mCurrentST.getExpType(node.getLExp());
        Type rexpType = this.mCurrentST.getExpType(node.getRExp());
        if ((lexpType==Type.INT  || lexpType==Type.BYTE) && (rexpType==Type.INT  || rexpType==Type.BYTE)){
            this.mCurrentST.setExpType(node, Type.INT);
        } else {
            throw new SemanticException("Operands to - operator must be INT or BYTE ", node.getLExp().getLine(),node.getLExp().getPos());
        }
    }
    
    public void outNegExp(NegExp node){
        Type expType = this.mCurrentST.getExpType(node.getExp());
        if (expType==Type.INT  || expType==Type.BYTE){
            this.mCurrentST.setExpType(node, Type.INT);
        } else {
            throw new SemanticException("Uminus operator must be INT or BYTE", node.getExp().getLine(),node.getExp().getPos());
        }
    }

    public void outEqualExp(EqualExp node){
        Type lexpType = this.mCurrentST.getExpType(node.getLExp());
        Type rexpType = this.mCurrentST.getExpType(node.getRExp());
        if ((lexpType==Type.INT  || lexpType==Type.BYTE || lexpType==Type.COLOR  || lexpType==Type.BUTTON|| lexpType==Type.BOOL) && (rexpType==Type.INT  || rexpType==Type.BYTE || rexpType==Type.COLOR  || rexpType==Type.BUTTON||rexpType==Type.BOOL)){
            this.mCurrentST.setExpType(node, Type.BOOL);
        } else {
            throw new SemanticException( "Operands to == operator must be INT, BYTE, COLOR, BOOL, or BUTTON", node.getLExp().getLine(),node.getLExp().getPos());
        }
    }
    
    public void outMeggyCheckButton(MeggyCheckButton node){
        Type expType = this.mCurrentST.getExpType(node.getExp());
        if (expType==Type.BUTTON){
            this.mCurrentST.setExpType(node, Type.BOOL);
        } else {
            throw new SemanticException("The signature of MeggyCheckButton() function is boolean MeggyCheckButton(Button button) ", node.getExp().getLine(),node.getExp().getPos());
        }
    }
    
    public void outMeggyGetPixel(MeggyGetPixel node){
        Type xexpType = this.mCurrentST.getExpType(node.getXExp());
        Type yexpType = this.mCurrentST.getExpType(node.getYExp());
        if ((xexpType==Type.BYTE ) && (yexpType==Type.BYTE)){
            this.mCurrentST.setExpType(node, Type.COLOR);
        } else {
            throw new SemanticException("The signature of MeggyGetPixel() function is void MeggyGetPixel(byte x byte y)",node.getXExp().getLine(),node.getXExp().getPos());
        }
    }
    
    public void outByteCast(ByteCast node){
        Type expType = this.mCurrentST.getExpType(node.getExp());
        if (expType==Type.INT || expType==Type.BYTE){
            this.mCurrentST.setExpType(node, Type.BYTE);
        } else {
            throw new SemanticException("Operands to Byte cast must be INT " + expType, node.getExp().getLine(), node.getExp().getPos());
        }
    }
    
    public void outBlockStatement(BlockStatement node) {}
	
    public void outMainClass(MainClass node) {}
	
    public void outProgram(Program node) {}
	
    public void outIntegerExp(IntLiteral node){
        this.mCurrentST.setExpType(node, Type.INT);
    }
	
    public void outColorExp(ColorLiteral node){
        this.mCurrentST.setExpType(node, Type.COLOR);
    }
    
    public void outButtonExp(ButtonLiteral node){
        this.mCurrentST.setExpType(node, Type.BUTTON);
    }
	
    public void outTrueExp(TrueLiteral node){
        this.mCurrentST.setExpType(node, Type.BOOL);
    }
    
    public void outFalseExp(FalseLiteral node){
        this.mCurrentST.setExpType(node, Type.BOOL);
    }
    
    public void outNotExp(NotExp node) {
        if(this.mCurrentST.getExpType(node.getExp()) != Type.BOOL) {
            throw new SemanticException("Invalid right operand type for operator ! ", node.getExp().getLine(), node.getExp().getPos());
        }
        this.mCurrentST.setExpType(node, Type.BOOL);
    }

    public void outIfStatement(IfStatement node, String a, String b)
    {
        if(this.mCurrentST.getExpType(node.getExp()) != Type.BOOL) {
            throw new SemanticException("If statement must contain a boolean value ",node.getExp().getLine(), node.getExp().getPos());
        }
        
        this.mCurrentST.setExpType(node, Type.VOID);
    }
    
    public void outWhileStatement(WhileStatement node){
        if(this.mCurrentST.getExpType(node.getExp()) != Type.BOOL) {
            throw new SemanticException("Invalid expression type for While ", node.getExp().getLine(), node.getExp().getPos());
        }
        
        this.mCurrentST.setExpType(node, Type.BOOL);
    }
    
    public void outMeggySetPixel(MeggySetPixel node)
    {
        Type xexpType = this.mCurrentST.getExpType(node.getXExp());
        Type yexpType = this.mCurrentST.getExpType(node.getYExp());
        Type colorexpType = this.mCurrentST.getExpType(node.getColor());
        if ((xexpType==Type.BYTE) && (yexpType==Type.BYTE) && (colorexpType==Type.COLOR)){
            this.mCurrentST.setExpType(node, Type.VOID);
        } else {
            throw new SemanticException("The signature of MeggySetPixel() function is void MeggySetPixel((byte) x, (byte) y, color c)", node.getXExp().getLine(),node.getXExp().getPos());
        }
    }
    
    public void outMeggyDelay(MeggyDelay node)
    {
        Type expType = this.mCurrentST.getExpType(node.getExp());
        if (expType==Type.INT){
            this.mCurrentST.setExpType(node, Type.VOID);
        } else {
            throw new SemanticException("The signature of MeggyDelay() function is void MeggyDelay(int duration)", node.getExp().getLine(), node.getExp().getPos());
        }
    }
	private Type typeCheck(IExp nodeExp, String nodeId, int nodeLine, int nodePos, LinkedList<IExp> nodeArgs)
	{

		Type locType1 = this.mCurrentST.getExpType(nodeExp);
		if((locType1 == null) || (!locType1.isRef()))
			throw new SemanticException("Method call receiver must be a class ", nodeLine, nodePos);
		
		ClassSTE locClassSTE = (ClassSTE)this.mCurrentST.lookup(locType1.getClassName());
		
        	MethodSTE locMethodSTE = (MethodSTE)this.mCurrentST.lookup(nodeId);
		if(locMethodSTE == null)
			throw new SemanticException("The method " + nodeId + " doesn't exist in class " + locClassSTE.mName + nodeLine + nodePos);

		Signature locSignature = locMethodSTE.getSignature();
		int i = nodeArgs.size();
		if(i != locSignature.formalCount())
			throw new SemanticException("The method " + nodeId + " needs " + locSignature.formalCount() + " arguments " + nodeLine + nodePos);
		
		IExp[] tempIExpArray = new IExp[i];
		tempIExpArray = (IExp[])nodeArgs.toArray(tempIExpArray);
		for(int j = 0; j < tempIExpArray.length; j++) {
			Type locType2 = this.mCurrentST.getExpType(tempIExpArray[j]);
			Type locType3 = locSignature.formalType(j);
			if((locType3 != locType2) && ((locType3 != Type.INT) || (locType2 != Type.BYTE))) 
				throw new SemanticException("Argument type for method " + nodeId + " is invalid ", tempIExpArray[j].getLine(), tempIExpArray[j].getPos());
		}
		return locSignature.getReturnType();
	}
	
	public void outMeggyToneStart(MeggyToneStart node)
	{
		Type toneExpType = this.mCurrentST.getExpType(node.getToneExp());
		Type durationExpType = this.mCurrentST.getExpType(node.getDurationExp());
		if ((toneExpType==Type.TONE) && (durationExpType==Type.INT)){
			this.mCurrentST.setExpType(node, Type.VOID);
		} else {
			throw new SemanticException("The signature of MeggyToneStart() function is void MeggyToneStart(Tone tone, int duration)", node.getToneExp().getLine(),node.getToneExp().getLine());	
		}
	}
	
	public void outBoolType(BoolType node) {}
	
	public void outButtonType(ButtonType node) {}
	
	public void outByteType(ByteType node) {}
	
	public void outCallExp(CallExp node) {}
	
	public void outCallStatement(CallStatement node){}

    	public void outIdLiteral(IdLiteral node) {}
	
	public void outColorType(ColorType node) {}
	
	public void outFormal(Formal node) {}
	
	public void outIntType(IntType node) {}
	
	public void outLtExp(LtExp node)
	{
	  	Type lexpType = this.mCurrentST.getExpType(node.getLExp());
       		Type rexpType = this.mCurrentST.getExpType(node.getRExp());
       		if ((lexpType==Type.INT  || lexpType==Type.BYTE) && (rexpType==Type.INT  || rexpType==Type.BYTE) ){
        		this.mCurrentST.setExpType(node, Type.BOOL);
       		} else {
           		throw new SemanticException("Operands to < operator must be INT or BYTE", node.getLExp().getLine(), node.getLExp().getPos());
       		}
	}

    	public void inMethodDecl(MethodDecl node) {}
	
	public void outMethodDecl(MethodDecl node) {}
	
	public void outNewExp(NewExp node) {}
	
	public void outThisExp(ThisLiteral node) {}
	
	public void outToneExp(ToneLiteral node) {
		this.mCurrentST.setExpType(node, Type.TONE);
	}
	
	public void outToneType(ToneType node) {}
	
	public void outTopClassDecl(TopClassDecl node) {}
	
	public void outVoidType(VoidType node) {}
}
