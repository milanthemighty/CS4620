package ast_visitors;

import java.io.PrintWriter;
import java.util.Stack;

import ast.visitor.DepthFirstVisitor;
import ast.node.*;

public class DotVisitor extends DepthFirstVisitor {
   private int nodeCount = 0;
   private PrintWriter out;
   private Stack<Integer> nodeStack;

   public DotVisitor(PrintWriter out) {
      this.out = out;
      this.nodeStack = new Stack<Integer>();
   }

   public void defaultIn(Node node) {
       if (nodeStack.empty()) {
           out.println("digraph ASTGraph {");
       }
       nodeDotOutput(node);
       nodeStack.push(nodeCount-1);    
   }
   
   public void defaultOut(Node node) {
       nodeStack.pop();
       if (nodeStack.empty()) {
           out.println("}");
       }
       out.flush();
   }
   
   private void nodeDotOutput(Node node)
   {
       out.print(nodeCount);
       out.print(" [ label=\"");
       printNodeName(node);
       if (node instanceof ILiteral) {
           out.print("\\n");
           out.print(node.toString());
       }
       out.println("\" ];");
       
       if (!nodeStack.empty()) {
           out.print(nodeStack.peek());
           out.print(" -> ");
           out.println(nodeCount);
       }
       nodeCount++;
   }
   private void printNodeName(Node node) {
      String fullName = node.getClass().getName();
      String name = fullName.substring(fullName.lastIndexOf('.')+1);
      
      out.print(name);
   }
   
}
