package symtable;
import java.io.PrintStream;
public abstract class STE
{
	public String mName;
	public abstract int outputDot(PrintStream output, int n);

}
