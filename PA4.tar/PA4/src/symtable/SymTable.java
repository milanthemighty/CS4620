package symtable;
import java.util.*;
import ast.node.*;

import exceptions.InternalException;
import symtable.Scope;
import java.io.PrintStream;

public class SymTable {
    public final HashMap<Node,Type> mExpType = new HashMap<Node,Type>();
    public final Stack<Scope> mStackScope = new Stack();
    public final Scope mGlobalScope = new Scope(null);
    public final HashMap<String, MethodSTE> map = new HashMap<String,MethodSTE>();
    public SymTable() {
	this.mStackScope.push(this.mGlobalScope);
    }
    
    public STE lookup(String sym) {
	Scope innermostScope = this.mStackScope.peek();
	return innermostScope.lookup(sym);
    }

    public void insert( STE ste) {
        Scope deepestScope = this.mStackScope.peek();
	deepestScope.insert(ste);
    }
    
    public void pushScope(String id) {
	STE ste = this.lookup(id);
	boolean meth_instance = ste instanceof MethodSTE;
	boolean classSTE_instance = ste instanceof ClassSTE;
	if(!meth_instance || !classSTE_instance)
	{
		throw new InternalException("Scope not found");
	}
	if(meth_instance)
	{
		MethodSTE meth_ste = (MethodSTE)ste;
		this.mStackScope.push(meth_ste.mScope);
	}
	if(classSTE_instance)
	{
		ClassSTE class_ste = (ClassSTE)ste;
		this.mStackScope.push(class_ste.mScope);
	}
	
    }
    
    public void popScope() {
	this.mStackScope.pop();
    }
	
    public void setExpType(Node exp, Type t)
    {
    	this.mExpType.put(exp, t);
    }
    
    public Type getExpType(Node exp)
    {
    	return this.mExpType.get(exp);
    }
    
    public void outputDot(PrintStream printStream) {
        printStream.println("digraph SymTable {");
        printStream.println("\tgraph [rankdir=\"LR\"];");
        printStream.println("\tnode [shape=record];");
        this.mGlobalScope.outputDot(printStream, 0);
        printStream.println("}");
    }
}
