Name: Milan Bharadwaj
Computing ID: MB4RQ

Made a bunch of clearly labeled test files, and used some of y'alls. 
All the AVR generates properly, but there are some issues with error detection with MJ.jar.
No videos cuz I already turned in my Meggy.

Working Test Cases + Y'all test cases test all of the functionalities of the grammar.
The Type Error test cases showcase some examples of type errors. 
