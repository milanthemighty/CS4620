import meggy.Meggy;

class TypeError1 {
    public static void main(String[] whatever){
    	new Dot().takeInt("String");
    }
}

class Dot {
    public void takeInt(int giggity) {
	giggity = giggity * 2; 
    }
}


