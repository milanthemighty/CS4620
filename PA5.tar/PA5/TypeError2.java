import meggy.Meggy;

class TypeError2 {
    public static void main(String[] whatever){
    	new Dot().takeInt(3.0);
    }
}

class Dot {
    public void takeInt(int giggity) {
	giggity = giggity * 2; 
    }
}


