import meggy.Meggy;

class WorkingTestCase2 {

    public static void main(String[] whatever){
        new Dot().run();
    }
}

class Dot {
    byte curr_x;
    byte curr_y;
    Meggy.Color dotcolor;
    int x; 
    
    public void run() {
        Meggy.Tone localvar;
        localvar = Meggy.Tone.Cs3;
        dotcolor = Meggy.Color.ORANGE;
        curr_x = (byte)3;
        curr_y = (byte)6;
	x = 0;

	while (x < 5) {
        	this.movedot(curr_x, (byte)(curr_y+(byte)1));
        	Meggy.toneStart(localvar, 100);
		x = x + 1;
	}
    }
    
    public void movedot(byte x, byte y) {
        if (this.inBounds(x, y)) {
            Meggy.setPixel(curr_x, curr_y, Meggy.Color.BLUE);
            
            Meggy.setPixel(x, y, dotcolor);

            curr_x = x;
            curr_y = y;
            
        } else {}

    }
    
    public boolean inBounds(byte x, byte y) {
        return ((byte)(0-1) < x) && (x < (byte)8) && ((byte)(0-1) < y) && (y < (byte)8);
    }

}
