package ast_visitors;
import java.io.PrintWriter;
import java.io.*;
import java.lang.*;
import ast.visitor.DepthFirstVisitor;
import ast.node.*;
import ast.node.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;
import symtable.*;
import exceptions.InternalException;
import exceptions.SemanticException;

public class AVRgenVisitor extends DepthFirstVisitor {
	private int nodeCount = 0;
	private int labelCount = 0;
	private PrintWriter out;
	private Stack<Integer> nodeStack;
	private SymTable mCurrentST;

	public String getLabel() {
		String ret = String.valueOf(labelCount);
		labelCount++;
		return ret;
	}

	public AVRgenVisitor(PrintWriter out, SymTable st) {
		this.out = out;
		this.nodeStack = new Stack<Integer>();
		this.mCurrentST = st;
	}
	public void defaultIn(Node node) {
		if (nodeStack.empty()) {
			System.out.println("Generate prolog using avrH.rtl.s");
			InputStream mainPrologue = null;
			BufferedReader reader = null;
			try {
				mainPrologue = this.getClass().getClassLoader().getResourceAsStream("avrH.rtl.s");
				reader = new BufferedReader(new InputStreamReader(mainPrologue));

				String line = null;
				while ((line = reader.readLine()) != null) {
					out.println(line);
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			} finally {
				try {
					if (mainPrologue != null) mainPrologue.close();
					if (reader != null) reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		nodeStack.push(nodeCount - 1);
	}

	public void print(String s) { out.println("    " + s); }

	public void printFunction(String s) { out.println(s); }

	public void printLabel(String s) { out.println("MJ_L" + s + ":"); }

	public void defaultOut(Node node) {}

	public void outProgram(Program node) { out.flush(); }

	public void outMainClass(MainClass node) {
		System.out.println("Generate epilog using avrF.rtl.s");
		InputStream mainPrologue = null;
		BufferedReader reader = null;
		try {
			mainPrologue = this.getClass().getClassLoader().getResourceAsStream("avrF.rtl.s");
			reader = new BufferedReader(new InputStreamReader(mainPrologue));
			String line = null;
			while ((line = reader.readLine()) != null) {
				out.println(line);
			}
		} catch (Exception e2) { e2.printStackTrace(); }
		try {
			if (mainPrologue != null) mainPrologue.close();
			if (reader != null) reader.close();
		} catch (IOException e) { e.printStackTrace(); }
	}

	public void visitAssignStatement(AssignStatement node) {
		node.getExp().accept(this);
		print("");

		VarSTE symbol = this.mCurrentST.lookupVar(node.getId());

		if (this.mCurrentST.varIsLocal(node.getId())) {
			if (this.mCurrentST.getExpType(node.getExp()).getAVRTypeSize() == 2) {
				print("pop    r24");
				print("pop    r25");
				print("std    Y + " + String.valueOf(symbol.offset + 1) + ", r25");
				print("std    Y + " + String.valueOf(symbol.offset) + ", r24");
				print("");
			}
			else {
				print("pop    r24");
				print("std    Y + " + String.valueOf(symbol.offset) + ", r24");
				print("");
			}
		}
		else {
			if (this.mCurrentST.getExpType(node.getExp()).getAVRTypeSize() == 2) {
				print("pop    r24");
				print("pop    r25");
				print("");
				print("ldd    r31, Y + 2");
				print("ldd    r30, Y + 1");
				print("std    Z + " + String.valueOf(symbol.offset + 1) + ", r25");
				print("std    Z + " + String.valueOf(symbol.offset) + ", r24");
				print("");
			}
			else {
				print("pop    r24");
				print("");
				print("ldd    r31, Y + 2");
				print("ldd    r30, Y + 1");
				print("std    Z + " + String.valueOf(symbol.offset) + ", r24");
				print("");
			}
		}
	}

	public void inTopClassDecl(TopClassDecl node) { mCurrentST.pushClassScope(node.getName()); }

	public void outTopClassDecl(TopClassDecl node) { mCurrentST.popScope(); }

	public void visitMethodDecl(MethodDecl node) {
		int pushes = 0;
		mCurrentST.pushMethodScope(node.getName());

		String methodName = node.getName();
		String parent = ((TopClassDecl) node.parent()).getName();

		String labelName = parent + "_" + methodName;
		int register = 22;

		print(".text");
		printFunction(".global " + labelName);
		print(".type  " + labelName + ", @function");
		printFunction(labelName + ":");
		print("push   r29");
		print("push   r28");
		print("ldi    r30, 0");
		print("push   r30");
		print("push   r30");
		if (node.getType() != null) {
			node.getType().accept(this);
		}
		for (STE ste : ((MethodScope) mCurrentST.mScopeStack.peek()).getSymbols()) {
			print("push r30");
			pushes++;
			if (ste.type == Type.INT) {
				print("push r30");
				pushes++;
			}
		}
		print("");
		print("in     r28,__SP_L__");
		print("in     r29,__SP_H__");
		print("");
		print("std    Y + 2, r25");
		print("std    Y + 1, r24");

		for (VarSTE ste : ((MethodScope) mCurrentST.mScopeStack.peek()).getFormals()) {
			if (ste.type == Type.INT) {
				print("std    Y + " + String.valueOf(ste.offset + 1) + ", r" + String.valueOf(register + 1));
				print("std    Y + " + String.valueOf(ste.offset) + ", r" + String.valueOf(register));
				register -= 2;
			} else {
				print("std    Y + " + String.valueOf(ste.offset) + ", r" + String.valueOf(register));
				register -= 2;
			}
		}
		print("");
		List<VarDecl> vars = new ArrayList<VarDecl>(node.getVarDecls());
		for (VarDecl e : vars)
			e.accept(this);

		{
			List<IStatement> copy = new ArrayList<IStatement>(node.getStatements());
			for (IStatement e : copy) {
				e.accept(this);
			}
		}
		if (node.getExp() != null) {
			node.getExp().accept(this);
		}
		printFunction("/* epilogue start for " + labelName + " */");
		if (node.getExp() != null) {
			String l0 = getLabel();
			String l1 = getLabel();
			print("pop   r24");
			if (mCurrentST.getExpType(node.getExp()) == Type.INT) {
				print("pop    r25");
			}
			else if (mCurrentST.getExpType(node.getExp()) == Type.BYTE) {
				print("tst     r24");
				print("brlt     MJ_L" + l0);
				print("ldi    r25, 0");
				print("jmp    MJ_L" + l1);
				printLabel(l0);
				print("ldi    r25, hi8(-1)");
				printLabel(l1);
			}
		}
		print("pop    r30");
		print("pop    r30");
		for (int i = 0; i < pushes; i++)
			print("pop    r30");

		print("pop    r28");
		print("pop    r29");
		print("ret");
		print(".size " + labelName + ", .-" + labelName);
		print("");

		mCurrentST.popScope();
	}
	public void visitFormal(Formal node) {}

	public void visitCallStatement(CallStatement node) {
		node.getExp().accept(this);
		mCurrentST.pushClassScope(mCurrentST.childClassName);

		LinkedList<IExp> args = node.getArgs();
		int register = 24 - 2 * args.size();
		String cl = mCurrentST.mScopeStack.peek().name;
		LinkedList<VarSTE> formals = mCurrentST.lookupMethod(node.getId()).scope.getFormals();

		mCurrentST.popScope();

		Iterator<VarSTE> formalItr = formals.listIterator();
		Iterator<IExp> argItr = args.listIterator();
		IExp arg;
		VarSTE formal;
		while (formalItr.hasNext()) {
			arg = argItr.next();
			formal = formalItr.next();

			arg.accept(this);

			if (formal.type == Type.BYTE) {
				print("pop    r" + register);
				register++;
				register++;
			}

			else {
				if (mCurrentST.getExpType(arg) == Type.BYTE) {
					String l0 = getLabel();
					String l1 = getLabel();
					print("pop    r" + String.valueOf(register));
					print("tst     r" + String.valueOf(register));
					register++;
					print("brlt     MJ_L" + l0);
					print("ldi    r" + String.valueOf(register) + ", 0");
					print("jmp    MJ_L" + l1);
					printLabel(l0);
					print("ldi    r" + String.valueOf(register) + ", hi8(-1)");
					printLabel(l1);
					print("");
					register++;
				}
				else {
					print("pop    r" + String.valueOf(register));
					register++;
					print("pop    r" + String.valueOf(register));
					register++;
				}
			}
		}
		print("pop    r24");
		print("pop    r25");
		print("");
		print("call    " + cl + "_" + node.getId());
	}

	public void visitCallExp(CallExp node) {
		node.getExp().accept(this);
		mCurrentST.pushClassScope(mCurrentST.childClassName);

		LinkedList<IExp> args = node.getArgs();
		int register = 24 - 2 * args.size();
		String cl = mCurrentST.mScopeStack.peek().name;

		LinkedList<VarSTE> formals = mCurrentST.lookupMethod(node.getId()).scope.getFormals();

		Type returnType = mCurrentST.lookupMethod(node.getId()).type;
		mCurrentST.popScope();

		Iterator<VarSTE> formalItr = formals.listIterator();
		Iterator<IExp> argItr = args.listIterator();
		IExp arg;
		VarSTE formal;
		while (formalItr.hasNext()) {
			arg = argItr.next();
			formal = formalItr.next();
			arg.accept(this);

			if (formal.type == Type.BYTE) {
				print("pop    r" + register);
			}

			else {
				if (mCurrentST.getExpType(arg) == Type.BYTE) {
					String l0 = getLabel();
					String l1 = getLabel();
					print("pop    r" + String.valueOf(register));
					register++;
					print("tst     r22");
					print("brlt     MJ_L" + l0);
					print("ldi    r2" + String.valueOf(register) + ", 0");
					print("jmp    MJ_L" + l1);
					printLabel(l0);
					print("ldi    r2" + String.valueOf(register) + ", hi8(-1)");
					printLabel(l1);
				}
				print("pop    r" + String.valueOf(register));
				register++;
				print("pop    r" + String.valueOf(register));
			}
			register++;
		}
		print("pop    r24");
		print("pop    r25");
		print("");
		print("call    " + cl + "_" + node.getId());

		if (returnType == Type.INT) {
			print("push   r25");
			print("push   r24");
			print("");
		} else if (returnType != Type.VOID) {
			print("push   r24");
			print("");
		}
	}

	public void visitNewExp(NewExp node) {
		mCurrentST.childClassName = node.getId();
		String size = String.valueOf((this.mCurrentST.lookupClass(node.getId()).scope).classSize);
		print("ldi    r24, lo8(" + size + ")");
		print("ldi    r25, hi8(" + size + ")");
		print("call    malloc");
		print("push   r25");
		print("push   r24");
		print("");
	}

	public void visitThisLiteral(ThisLiteral node) {
		print("");
		print("ldd    r31, Y + 2");
		print("ldd    r30, Y + 1");
		print("push   r31");
		print("push   r30");
		print("");
		Scope first = mCurrentST.mScopeStack.pop();
		String className = mCurrentST.mScopeStack.peek().name;
		mCurrentST.mScopeStack.push(first);
		mCurrentST.childClassName = className;
	}

	public void inBlockStatement(BlockStatement node) { print(""); }

	public void outBlockStatement(BlockStatement node) { print(""); }

	public void outMeggySetPixel(MeggySetPixel node) {
		print("pop    r20");
		print("pop    r22");
		print("pop    r24");
		print("call   _Z6DrawPxhhh");
		print("call   _Z12DisplaySlatev");
		print("");
	}
	public void outMeggyToneStart(MeggyToneStart node) {
		print("pop    r22");
		print("pop    r23");
		print("pop    r24");
		print("pop    r25");
		print("call   _Z10Tone_Startjj");
	}
	public void outMeggyDelay(MeggyDelay node) {
		print("pop    r24");
		print("pop    r25");
		print("call   _Z8delay_msj");
		print("");
	}
	public void visitWhileStatement(WhileStatement node) {
		String l0 = getLabel();
		printLabel(l0);
		print("");
		if (node.getExp() != null) {
			node.getExp().accept(this);
		}
		String l1 = getLabel();
		String l2 = getLabel();
		print("pop    r24");
		print("ldi    r25,0");
		print("cp     r24, r25");
		print("brne   MJ_L" + l1);
		print("jmp    MJ_L" + l2);
		print("");
		printLabel(l1);
		print("");
		if (node.getStatement() != null) {
			node.getStatement().accept(this);
		}
		print("jmp    MJ_L" + l0);
		print("");
		printLabel(l2);
		print("");
	}

	public void visitIfStatement(IfStatement node) {
		print("#### if statement");
		print("");
		if (node.getExp() != null) {
			node.getExp().accept(this);
		}
		String l0 = getLabel();
		String l1 = getLabel();
		print("pop    r24");
		print("ldi    r25, 0");
		print("");
		print("cp     r24, r25");
		print("brne   MJ_L" + l1);
		print("jmp    MJ_L" + l0);
		print("");
		printLabel(l1);
		print("");
		if (node.getThenStatement() != null) {
			node.getThenStatement().accept(this);
		}
		String l2 = getLabel();

		print("jmp MJ_L" + l2);
		print("");
		printLabel(l0);

		if (node.getElseStatement() != null) {
			node.getElseStatement().accept(this);
		}
		printLabel(l2);
	}
	public void outPlusExp(PlusExp node) {
		if (mCurrentST.getExpType(node.getLExp()) == Type.BYTE) {
			String l4 = getLabel();
			String l5 = getLabel();
			print("pop	r18");
			print("tst     r18");
			print("brlt     MJ_L" + l4);
			print("ldi    r19, 0");
			print("jmp    MJ_L" + l5);
			printLabel(l4);
			print("ldi    r19, hi8(-1)");
			printLabel(l5);
		} else {
			print("pop    r18");
			print("pop    r19");

		}
		if (mCurrentST.getExpType(node.getRExp()) == Type.BYTE) {
			String l4 = getLabel();
			String l5 = getLabel();
			print("pop	r24");
			print("tst     r24");
			print("brlt     MJ_L" + l4);
			print("ldi    r25, 0");
			print("jmp    MJ_L" + l5);
			printLabel(l4);
			print("ldi    r25, hi8(-1)");
			printLabel(l5);
		} else {
			print("pop    r24");
			print("pop    r25");
		}
		print("add    r24, r18");
		print("adc    r25, r19");
		print("push   r25");
		print("push   r24");
		print("");
	}

	public void outMinusExp(MinusExp node) {
		if (mCurrentST.getExpType(node.getLExp()) == Type.BYTE) {
			String l4 = getLabel();
			String l5 = getLabel();
			print("pop	r18");
			print("tst     r18");
			print("brlt     MJ_L" + l4);
			print("ldi    r19, 0");
			print("jmp    MJ_L" + l5);
			printLabel(l4);
			print("ldi    r19, hi8(-1)");
			printLabel(l5);
		} else {
			print("pop    r18");
			print("pop    r19");

		}
		if (mCurrentST.getExpType(node.getRExp()) == Type.BYTE) {
			String l4 = getLabel();
			String l5 = getLabel();
			print("pop	r24");
			print("tst     r24");
			print("brlt     MJ_L" + l4);
			print("ldi    r25, 0");
			print("jmp    MJ_L" + l5);
			printLabel(l4);
			print("ldi    r25, hi8(-1)");
			printLabel(l5);
		} else {
			print("pop    r24");
			print("pop    r25");
		}
		print("sub    r24, r18");
		print("sbc    r25, r19");
		print("push   r25");
		print("push   r24");
		print("");

	}

	public void outMulExp(MulExp node) {
		print("pop    r18");
		print("pop    r22");
		print("mov    r24, r18");
		print("mov    r26, r22");
		print("");
		print("muls   r24, r26");
		print("push   r1");
		print("push   r0");
		print("eor    r0,r0");
		print("eor    r1,r1");
		print("");
	}

	public void outEqualExp(EqualExp node) {
		String l3 = getLabel();
		String l4 = getLabel();
		String l5 = getLabel();
		if (mCurrentST.getExpType(node.getLExp()) == Type.INT) {
			print("pop    r18");
			print("pop    r19");
			print("pop    r24");
			print("pop    r25");
			print("cp    r24, r18");
			print("cpc   r25, r19");
		} 
		else {
			print("pop    r18");
			print("pop    r24");
			print("cp    r24, r18");
		}
		print("breq MJ_L" + l4);
		print("");
		printLabel(l3);
		print("ldi     r24, 0");
		print("jmp      MJ_L5");
		print("");
		printLabel(l4);
		print("ldi     r24, 1");
		print("");
		printLabel(l5);
		print("push   r24");
		print("");
	}

	public void visitAndExp(AndExp node) {
		String l3 = getLabel();
		String l4 = getLabel();
		if (node.getLExp() != null) {
			node.getLExp().accept(this);
		}
		print("pop    r24");
		print("push   r24");
		print("ldi r25, 0");
		print("cp    r24, r25");
		print("brne  MJ_L" + l4);
		print("jmp   MJ_L" + l3);
		print("");
		printLabel(l4);
		print("pop    r24");
		print("");
		if (node.getRExp() != null) {
			node.getRExp().accept(this);
		}
		print("pop    r24");
		print("push   r24");
		print("");
		printLabel(l3);
		print("");
	}

	public void outLtExp(LtExp node) {
		String l3 = getLabel();
		String l4 = getLabel();
		String l5 = getLabel();
		if (mCurrentST.getExpType(node.getLExp()) == Type.INT) {
			print("pop    r18");
			print("pop    r19");
			print("pop    r24");
			print("pop    r25");
			print("cp    r24, r18");
			print("cpc   r25, r19");
		} else {
			print("pop    r18");
			print("pop    r24");
			print("cp    r24, r18");
		}
		print("brlt MJ_L" + l4);
		print("");
		printLabel(l3);
		print("ldi     r24, 0");
		print("jmp      MJ_L" + l5);
		print("");
		printLabel(l4);
		print("ldi    r24, 1");
		print("");
		printLabel(l5);
		print("push   r24");
		print("");

	}

	public void outByteCast(ByteCast node) {
		if (node.getExp() instanceof ByteCast)
			return;
		print("pop    r24");
		print("pop    r25");
		print("push   r24");
		print("");

	}

	public void outNotExp(NotExp node) {
		print("pop    r24");
		print("ldi     r22, 1");
		print("eor     r24,r22");
		print("push   r24");
		print("");

	}
	public void outNegExp(NegExp node) {
		print("pop    r24");
		print("pop    r25");
		print("ldi     r22, 0");
		print("ldi     r23, 0");
		print("sub     r22, r24");
		print("sbc     r23, r25");
		print("push   r23");
		print("push   r22");
		print("");

	}

	public void inMeggyCheckButton(MeggyCheckButton node) {
		print("call   _Z16CheckButtonsDownv");
		out.print("    lds   r24, ");
	}

	public void outMeggyCheckButton(MeggyCheckButton node) {
		String l3 = getLabel();
		String l5 = getLabel();
		String l4 = getLabel();
		print("tst   r24");
		print("breq   MJ_L" + l3);
		printLabel(l4);
		print("ldi   r24, 1");
		print("jmp   MJ_L" + l5);
		printLabel(l3);
		printLabel(l5);
		print("push   r24");
		print("");
	}

	public void outMeggyGetPixel(MeggyGetPixel node) {
		print("pop    r22");
		print("pop    r24");
		print("call   _Z6ReadPxhh");
		print("push   r24");
		print("");
	}

	public void inIntegerExp(IntLiteral node) {		
		print("ldi r24, lo8(" + node.getIntValue() + ")");
		print("ldi r25, hi8(" + node.getIntValue() + ")");
		print("push r25");
		print("push r24");
		print("");
	}

	public void inColorExp(ColorLiteral node) {
		print("ldi    r22, " + node.getIntValue());
		print("push   r22");
		print("");

	}

	public void outButtonExp(ButtonLiteral node) {
		String button = "";
		switch (node.getIntValue()) {
		case 1: button = "Button_B"; break;
		case 2: button = "Button_A"; break;
		case 4: button = "Button_Up"; break;
		case 8: button = "Button_Down"; break;
		case 16: button = "Button_Left"; break;
		case 32: button = "Button_Right"; break;
		}
		print(button);
	}

	public void inTrueExp(TrueLiteral node) {
		print("ldi r22, 1");
		print("push r22");
	}

	public void inFalseExp(TrueLiteral node) {
		print("ldi r22, 0");
		print("push r22");
	}

	public void inToneExp(ToneLiteral node) {
		print("ldi    r25, hi8(" + node.getIntValue() + ")");
		print("ldi    r24, lo8(" + node.getIntValue() + ")");
		print("push   r25");
		print("push   r24");
		print("");
	}

	public void inIdLiteral(IdLiteral node) {
		VarSTE symbol = this.mCurrentST.lookupVar(node.getLexeme());
		mCurrentST.childClassName = mCurrentST.lookupVar(node.getLexeme()).classTypeName;
		print("");
		if (this.mCurrentST.varIsLocal(symbol.name)) {
			if (symbol.type.getAVRTypeSize() == 2) {
				print("ldd    r25, Y + " + String.valueOf(symbol.offset + 1));
				print("ldd    r24, Y + " + String.valueOf(symbol.offset));
				print("push   r25");
				print("push   r24");
				print("");
			}
			else {
				print("ldd    r24, Y + " + String.valueOf(symbol.offset));
				print("push   r24");
				print("");
			}	
		}
		else {
			print("");
			print("ldd    r31, Y + 2");
			print("ldd    r30, Y + 1");
			print("");
			if (symbol.type.getAVRTypeSize() == 2) {
				print("ldd    r25, Z + " + String.valueOf(symbol.offset + 1));
				print("ldd    r24, Z + " + String.valueOf(symbol.offset));
				print("push   r25");
				print("push   r24");
				print("");
			}
			else {
				print("ldd    r24, Z + " + String.valueOf(symbol.offset));
				print("push   r24");
				print("");
			}
		}
	}
}
