package ast_visitors;
import java.io.PrintWriter;
import java.util.Stack;
import ast.visitor.DepthFirstVisitor;
import ast.node.*;
import symtable.*;
import exceptions.*;

public class BuildSymTable extends DepthFirstVisitor {

	private SymTable mCurrentST;

	public BuildSymTable() {
		mCurrentST = new SymTable();
	}

	public SymTable getSymTable() {
		return mCurrentST;
	}

	public void inProgram(Program node) {
		for (IClassDecl ic : node.getClassDecls()) {
			TopClassDecl c = (TopClassDecl)ic;
			if (mCurrentST.lookupInnermostSymbol(c.getName()) != null) {
				throw new SemanticException("Redefined symbol " + c.getName(), c.getLine(), c.getPos());
			}
			mCurrentST.insertClass(c);
		}
		for (IClassDecl ic : node.getClassDecls()) {
			TopClassDecl c = (TopClassDecl)ic;						
			mCurrentST.pushClassScope(c.getName());
			for (VarDecl var : c.getVarDecls()) {
				if (mCurrentST.lookupInnermostSymbol(var.getName()) != null) {
					throw new SemanticException("Redefined symbol " + var.getName(), var.getLine(), var.getPos());
				}
				mCurrentST.insertMemberVar(var);
			}
			for (MethodDecl method : c.getMethodDecls()) {
				if (mCurrentST.lookupInnermostSymbol(method.getName()) != null) {
					throw new SemanticException("Redefined symbol " + method.getName(), method.getLine(),
							method.getPos());
				}
				mCurrentST.insertMethod(method);
			}
			mCurrentST.popScope();
		}
	}

	public void visitTopClassDecl(TopClassDecl node) {
		mCurrentST.pushClassScope(node.getName());

		int classSize = 0;
		for (MemberVarSTE var : ((ClassScope) mCurrentST.mScopeStack.peek()).getMemberVars()) {
			classSize += var.type.getAVRTypeSize();
		}
		((ClassScope) mCurrentST.mScopeStack.peek()).classSize = classSize;

		for (MethodDecl method : node.getMethodDecls()) {
			mCurrentST.pushMethodScope(method.getName());
			for (Formal formal : method.getFormals()) {
				if (mCurrentST.lookupInnermostSymbol(formal.getName()) != null) {
					throw new SemanticException("Redefined symbol " + formal.getName(), formal.getLine(),
							formal.getPos());
				}
				mCurrentST.insertFormal(formal);
			}
			for (VarDecl var : method.getVarDecls()) {
				if (mCurrentST.lookupInnermostSymbol(var.getName()) != null) {
					throw new SemanticException("Redefined symbol " + var.getName(), var.getLine(), var.getPos());
				}
				mCurrentST.insertLocalVar(var);
			}
			mCurrentST.popScope();
		}
		mCurrentST.popScope();
	}
}
