package ast_visitors;
import ast.node.*;
import ast.visitor.DepthFirstVisitor;
import java.util.*;
import symtable.*;
import exceptions.InternalException;
import exceptions.SemanticException;

public class CheckTypes extends DepthFirstVisitor {

	private SymTable mCurrentST;

	public CheckTypes(SymTable st) {
		if (st == null) {
			throw new InternalException("unexpected null argument");
		}
		mCurrentST = st;
	}

	public void defaultOut(Node node) {
		System.err.println("Node not implemented in CheckTypes, " + node.getClass());
	}

	public void visitAssignStatement(AssignStatement node) {
		node.getExp().accept(this);

		Type idType = mCurrentST.lookupVar(node.getId()).type;
		Type expType = mCurrentST.getExpType(node.getExp());

		if (idType != expType) {
			if (idType == Type.INT && expType == Type.BYTE) return;
			throw new SemanticException(
				"Invalid expression type assigned to variable " + node.getId(),
				node.getLine(), node.getPos()
			);
		}
	}

	public void outNewExp(NewExp node) {
		this.mCurrentST.setExpType(node, mCurrentST.lookupClass(node.getId()).type);
		mCurrentST.childClassName = node.getId();
	}

	public void outThisExp(ThisLiteral node) {
		Scope first = mCurrentST.mScopeStack.pop();
		String cname = mCurrentST.mScopeStack.peek().name;
		ClassSTE c = mCurrentST.lookupClass(cname);
		mCurrentST.mScopeStack.push(first);
		this.mCurrentST.setExpType(node, c.type);
		mCurrentST.childClassName = cname;
	}

	public void visitCallStatement(CallStatement node) {
		node.getExp().accept(this);
		mCurrentST.pushClassScope(mCurrentST.childClassName);

		this.mCurrentST.pushMethodScope(node.getId());

		for (IExp param : node.getArgs()) {
			param.accept(this);
		}

		LinkedList<IExp> actuals = (LinkedList<IExp>) node.getArgs().clone();
		IExp arg;
		for (VarSTE param : ((MethodScope) this.mCurrentST.mScopeStack.peek()).getFormals()) {
			arg = actuals.poll();
			if (arg == null) {
				throw new SemanticException("Method call " + node.getId() + " has too few arguments",
						node.getExp().getLine(), node.getExp().getPos());
			}

			if (this.mCurrentST.getExpType(arg) != param.type) {
				if (param.type == Type.INT && this.mCurrentST.getExpType(arg) == Type.BYTE)
					break;
				throw new SemanticException("Method arg " + param.name + " of incorrect type. Should be " + param.type
						+ ", is " + this.mCurrentST.getExpType(arg), arg.getLine(), arg.getPos());
			}
		}
		this.mCurrentST.popScope();
		this.mCurrentST.popScope();
	}

	public void visitCallExp(CallExp node) {
		node.getExp().accept(this);
		mCurrentST.pushClassScope(mCurrentST.childClassName);
		this.mCurrentST.pushMethodScope(node.getId());

		for (IExp param : node.getArgs()) {
			param.accept(this);
		}

		LinkedList<IExp> actuals = (LinkedList<IExp>) node.getArgs().clone();
		IExp arg;
		for (VarSTE param : ((MethodScope) this.mCurrentST.mScopeStack.peek()).getFormals()) {
			arg = actuals.poll();
			if (arg == null) {
				throw new SemanticException("Method call " + node.getId() + " has too few arguments",
						node.getExp().getLine(), node.getExp().getPos());
			}

			if (this.mCurrentST.getExpType(arg) != param.type) {
				if (param.type == Type.INT && this.mCurrentST.getExpType(arg) == Type.BYTE)
					break;
				throw new SemanticException("Method arg " + param.name + " of incorrect type. Should be " + param.type
						+ ", is " + this.mCurrentST.getExpType(arg), arg.getLine(), arg.getPos());
			}

		}
		this.mCurrentST.popScope();
		this.mCurrentST.setExpType(node, mCurrentST.lookupMethod(node.getId()).type);
		this.mCurrentST.popScope();
	}

	public void outIntType(IntType node) {}
	public void outByteType(ByteType node) {}
	public void outVoidType(VoidType node) {}
	public void outBoolType(BoolType node) {}
	public void outColorType(ColorType node) {}
	public void outClassType(ClassType node) {}
	public void outToneType(ToneType node) {}
	public void visitFormal(Formal node) {}
	public void visitVarDecl(VarDecl node) {}

	public void outIdLiteral(IdLiteral node) {
		if (mCurrentST.lookupSymbol(node.getLexeme()) == null) {
			throw new SemanticException("Undefined symbol " + node.getLexeme(), node.getLine(), node.getPos());
		}
		this.mCurrentST.setExpType(node, this.mCurrentST.lookupSymbol(node.getLexeme()).type);
		if (mCurrentST.lookupVar(node.getLexeme()) != null) {
			mCurrentST.childClassName = mCurrentST.lookupVar(node.getLexeme()).classTypeName;
		}
	}

	public void visitMethodDecl(MethodDecl node) {
		Type methodType = mCurrentST.lookupMethod(node.getName()).type;
		inMethodDecl(node);

		if (node.getType() != null) {
			node.getType().accept(this);
		}
		{
			List<Formal> copy = new ArrayList<Formal>(node.getFormals());
			for (Formal e : copy) {
				e.accept(this);
			}
		}
		{
			List<VarDecl> copy = new ArrayList<VarDecl>(node.getVarDecls());
			for (VarDecl e : copy) {
				e.accept(this);
			}
		}
		{
			List<IStatement> copy = new ArrayList<IStatement>(node.getStatements());
			for (IStatement e : copy) {
				e.accept(this);
			}
		}
		if (node.getExp() != null) {
			node.getExp().accept(this);
			Type returnType = mCurrentST.getExpType(node.getExp());
			if (returnType != methodType && (returnType != Type.BYTE && methodType != Type.INT)) {
				throw new SemanticException("Invalid type returned from method " + node.getName(), node.getLine(),
						node.getPos());
			}
		} else if (methodType != Type.VOID)
			throw new SemanticException("Method must return " + methodType, node.getLine(), node.getPos());
		outMethodDecl(node);
	}

	public void inMethodDecl(MethodDecl node) {
		this.mCurrentST.pushMethodScope(node.getName());
	}

	public void outMethodDecl(MethodDecl node) {
		this.mCurrentST.popScope();
	}

	public void inTopClassDecl(TopClassDecl node) {
		this.mCurrentST.pushClassScope(node.getName());
	}

	public void outTopClassDecl(TopClassDecl node) {
		this.mCurrentST.popScope();
	}

	public void outByteCast(ByteCast node) {
		if (this.mCurrentST.getExpType(node.getExp()) != Type.BYTE
				&& this.mCurrentST.getExpType(node.getExp()) != Type.INT) {
			throw new SemanticException("Invalid byte cast", node.getExp().getLine(), node.getExp().getPos());
		}
		this.mCurrentST.setExpType(node, Type.BYTE);
	}

	public void outIntegerExp(IntLiteral node) {
		this.mCurrentST.setExpType(node, Type.INT);
	}

	public void outColorExp(ColorLiteral node) {
		this.mCurrentST.setExpType(node, Type.COLOR);
	}

	public void outButtonExp(ButtonLiteral node) {
		this.mCurrentST.setExpType(node, Type.BUTTON);
	}

	public void outTrueExp(TrueLiteral node) {
		this.mCurrentST.setExpType(node, Type.BOOL);
	}

	public void outFalseExp(FalseLiteral node) {
		this.mCurrentST.setExpType(node, Type.BOOL);
	}

	public void outToneExp(ToneLiteral node) {
		this.mCurrentST.setExpType(node, Type.TONE);
	}

	public void outAndExp(AndExp node) {
		if (this.mCurrentST.getExpType(node.getLExp()) != Type.BOOL) {
			throw new SemanticException("Invalid left operand type for operator &&", node.getLExp().getLine(),
					node.getLExp().getPos());
		}

		if (this.mCurrentST.getExpType(node.getRExp()) != Type.BOOL) {
			throw new SemanticException("Invalid right operand type for operator &&", node.getRExp().getLine(),
					node.getRExp().getPos());
		}

		this.mCurrentST.setExpType(node, Type.BOOL);
	}
	public void outEqualExp(EqualExp node) {
		if (!(((this.mCurrentST.getExpType(node.getLExp()) == Type.BOOL)
				& (this.mCurrentST.getExpType(node.getRExp()) == Type.BOOL))
				|| ((this.mCurrentST.getExpType(node.getLExp()) == Type.BYTE)
						& (this.mCurrentST.getExpType(node.getRExp()) == Type.BYTE))
				|| ((this.mCurrentST.getExpType(node.getLExp()) == Type.BUTTON)
						& (this.mCurrentST.getExpType(node.getRExp()) == Type.BUTTON))
				|| ((this.mCurrentST.getExpType(node.getLExp()) == Type.COLOR)
						& (this.mCurrentST.getExpType(node.getRExp()) == Type.COLOR)))
				|| ((this.mCurrentST.getExpType(node.getLExp()) == Type.INT)
						& (this.mCurrentST.getExpType(node.getRExp()) == Type.INT))) {
			throw new SemanticException("Invalid operands aren't of the same type for operator ==",
					node.getLExp().getLine(), node.getLExp().getPos());
		}

		this.mCurrentST.setExpType(node, Type.BOOL);
	}

	public void outLtExp(LtExp node) {
		Type xexpType = this.mCurrentST.getExpType(node.getLExp());
		Type yexpType = this.mCurrentST.getExpType(node.getRExp());
		if ((xexpType == Type.INT || xexpType == Type.BYTE) && (yexpType == Type.INT || yexpType == Type.BYTE)) {
			this.mCurrentST.setExpType(node, Type.COLOR);
		} else {
			throw new SemanticException("Operands to < operator must be of numeric types", node.getLExp().getLine(),
					node.getRExp().getPos());
		}
		this.mCurrentST.setExpType(node, Type.BOOL);
	}

	public void outNotExp(NotExp node) {
		if (this.mCurrentST.getExpType(node.getExp()) != Type.BOOL) {
			throw new SemanticException("Invalid operand type for operator ~", node.getExp().getLine(),
					node.getExp().getPos());
		}
		this.mCurrentST.setExpType(node, Type.BOOL);
	}

	public void outMeggyGetPixel(MeggyGetPixel node) {
		Type xexpType = this.mCurrentST.getExpType(node.getXExp());
		Type yexpType = this.mCurrentST.getExpType(node.getYExp());
		if ((xexpType == Type.INT || xexpType == Type.BYTE) && (yexpType == Type.INT || yexpType == Type.BYTE)) {
			this.mCurrentST.setExpType(node, Type.COLOR);
		} else {
			throw new SemanticException("Parameters for MeggyGetPixel must be INT or BYTE", node.getXExp().getLine(),
					node.getXExp().getPos());
		}
	}

	public void outNegExp(NegExp node) {
		if (this.mCurrentST.getExpType(node.getExp()) != Type.INT
				&& this.mCurrentST.getExpType(node.getExp()) != Type.BYTE) {
			throw new SemanticException("Invalid operand type for the operator - (negative)", node.getExp().getLine(),
					node.getExp().getPos());
		}
		this.mCurrentST.setExpType(node, Type.INT);
	}

	public void outMeggyCheckButton(MeggyCheckButton node) {
		if (this.mCurrentST.getExpType(node.getExp()) != Type.BUTTON) {
			throw new SemanticException("Invalid button expression for MeggyGetButton", node.getExp().getLine(),
					node.getExp().getPos());
		}
		this.mCurrentST.setExpType(node, Type.BOOL);
	}

	public void outMeggyToneStart(MeggyToneStart node) {
		if (this.mCurrentST.getExpType(node.getToneExp()) != Type.TONE) {
			throw new SemanticException("Tone: Invalid argument type for method MeggyToneStart",
					node.getToneExp().getLine(), node.getToneExp().getPos());
		}
		if (this.mCurrentST.getExpType(node.getDurationExp()) != Type.INT) {
			throw new SemanticException("Duration: Invalid argument type for method MeggyToneStart",
					node.getDurationExp().getLine(), node.getDurationExp().getPos());
		}
	}

	public void outPlusExp(PlusExp node) {
		Type lexpType = this.mCurrentST.getExpType(node.getLExp());
		Type rexpType = this.mCurrentST.getExpType(node.getRExp());
		if ((lexpType == Type.INT || lexpType == Type.BYTE) && (rexpType == Type.INT || rexpType == Type.BYTE)) {
			this.mCurrentST.setExpType(node, Type.INT);
		} else {
			throw new SemanticException("Operands to + operator must be INT or BYTE", node.getLExp().getLine(),
					node.getLExp().getPos());
		}
	}

	public void outMinusExp(MinusExp node) {
		Type lexpType = this.mCurrentST.getExpType(node.getLExp());
		Type rexpType = this.mCurrentST.getExpType(node.getRExp());
		if ((lexpType == Type.INT || lexpType == Type.BYTE) && (rexpType == Type.INT || rexpType == Type.BYTE)) {
			this.mCurrentST.setExpType(node, Type.INT);
		} else {
			throw new SemanticException("Operands to - operator must be INT or BYTE", node.getLExp().getLine(),
					node.getLExp().getPos());
		}
	}

	public void outMulExp(MulExp node) {
		Type lexpType = this.mCurrentST.getExpType(node.getLExp());
		Type rexpType = this.mCurrentST.getExpType(node.getRExp());
		if ((lexpType == Type.BYTE) && (rexpType == Type.BYTE)) {
			this.mCurrentST.setExpType(node, Type.INT);
		} else {
			throw new SemanticException("Operands to * operator must be BYTE", node.getLExp().getLine(),
					node.getLExp().getPos());
		}
		this.mCurrentST.setExpType(node, Type.INT);
	}

	public void outMeggySetPixel(MeggySetPixel node) {
		Type xexpType = this.mCurrentST.getExpType(node.getXExp());
		Type yexpType = this.mCurrentST.getExpType(node.getYExp());
		Type cexpType = this.mCurrentST.getExpType(node.getColor());
		if ((xexpType != Type.BYTE) & (yexpType != Type.BYTE)) {
			throw new SemanticException("Parameter for MeggySetPixel must be of type BYTE", node.getXExp().getLine(),
					node.getXExp().getPos());
		}
		if ((cexpType != Type.COLOR)) {
			throw new SemanticException("Parameter for MeggySetPixel must be of type COLOR", node.getColor().getLine(),
					node.getColor().getPos());
		}
	}

	public void outMeggyDelay(MeggyDelay node) {
		if ((this.mCurrentST.getExpType(node.getExp()) != Type.INT)) {
			throw new SemanticException("Parameter for MeggyDelay must be of type INT", node.getExp().getLine(),
					node.getExp().getPos());
		}
	}

	public void outIfStatement(IfStatement node) {
		if (this.mCurrentST.getExpType(node.getExp()) != Type.BOOL) {
			throw new SemanticException("Parameter for IfStatement must be of type BOOL", node.getExp().getLine(),
					node.getExp().getPos());
		}
	}

	public void outWhileStatement(WhileStatement node) {
		if (this.mCurrentST.getExpType(node.getExp()) != Type.BOOL) {
			throw new SemanticException("Parameter for WhileStatement must be of type BOOL", node.getExp().getLine(),
					node.getExp().getPos());
		}
	}

	public void outBlockStatement(BlockStatement node) {}

	public void outMainClass(MainClass node) {}

	public void outProgram(Program node) {}

}
