package ast_visitors;
import java.io.PrintWriter;
import java.util.Stack;
import java.util.HashMap;
import ast.visitor.DepthFirstVisitor;
import ast.node.*;

public class DotVisitorWithMap extends DepthFirstVisitor {
   private int nodeCount = 0;
   private PrintWriter out;
   private Stack<Integer> nodeStack;
   private HashMap<Node,String> mMap;
   

   public DotVisitorWithMap(PrintWriter out, HashMap<Node,String> map) {
      this.out = out;
      this.nodeStack = new Stack<Integer>();
      this.mMap = map;
   }
   public void defaultIn(Node node) {
       if (nodeStack.empty()) {
           out.println("digraph ASTGraph {");
       }

       nodeDotOutput(node);
       nodeStack.push(nodeCount-1);    
   }
   
   public void defaultOut(Node node) {
       nodeStack.pop();
       if (nodeStack.empty()) {
           out.println("}");
       }
       out.flush();
   }
   private void nodeDotOutput(Node node)
   {
       out.print(nodeCount);
       out.print(" [ label=\"");
       printNodeName(node);
       if (this.mMap.containsKey(node)) {
           out.print("\\n"+this.mMap.get(node));
       }
       if (node instanceof ILiteral) {
           out.print("\\n");
           out.print(node.toString());
       }
       out.println("\" ];");
       
       if (!nodeStack.empty()) {
           out.print(nodeStack.peek());
           out.print(" -> ");
           out.println(nodeCount);
       }
       
       nodeCount++;
   }
   private void printNodeName(Node node) {
      String fullName = node.getClass().getName();
      String name = fullName.substring(fullName.lastIndexOf('.')+1);
      
      out.print(name);
   }
   
}
