package symtable;
import java.util.*;
import ast.node.*;

public class ClassSTE extends STE {
	public int offsetCount;
	public ClassScope scope;

	public ClassSTE(TopClassDecl node) {
		super(node, new Type());
		this.name = node.getName();
		scope = new ClassScope(this.name);
		offsetCount = 1;
	}

	public String toString() {
		return "\tClass STE " + this.name + " of type " + "TYPE" + "\n" + this.scope;
	}
}
