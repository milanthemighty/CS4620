package symtable;

import java.util.*;
import ast.node.*;

public class MainScope extends Scope {
	private LinkedHashMap<String, ClassSTE> classes;

	public MainScope() {
		super("main");
		this.classes = new LinkedHashMap<String, ClassSTE>();
		this.offsetCount = 1;
	}
	public void addClass(TopClassDecl node) {
		ClassSTE newSTE = new ClassSTE(node);
		this.symbols.put(node.getName(), newSTE);
		this.classes.put(node.getName(), newSTE);
		
	}

	public ClassSTE lookupClass(String sym) {
		return classes.get(sym);
	}

	public LinkedList<ClassSTE> getClasses() {
		LinkedList<ClassSTE> l = new LinkedList<ClassSTE>();
		l.addAll(this.classes.values());
		return l;
	}

	public String toString() {
		String result = "Main scope of program:\n";
		result += "\tVariables:\n";
		result += "\tClasses:\n";
		for (ClassSTE ste : classes.values())
			result += ste.toString() + "\n";
		return result;
	}
}
