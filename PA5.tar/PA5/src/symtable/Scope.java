package symtable;
import java.util.*;
import ast.node.*;

public abstract class Scope {
	public LinkedHashMap<String, STE> symbols;
	public String name;
	public int offsetCount;

	public Scope(String name) {
		this.symbols = new LinkedHashMap<String, STE>();
		this.name = name;
	}
	public LinkedList<STE> getSymbols() {
		LinkedList<STE> l = new LinkedList<STE>();
		l.addAll(this.symbols.values());
		return l;
	}
	public STE lookupSymbol(String sym) {
		return symbols.get(sym);
	}

}
