package symtable;
import java.util.*;
import ast.node.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.PrintStream;
import exceptions.*;

public class SymTable {
    private HashMap<Node, Type> mExpType;
    public MainScope main;
    public Stack<Scope> mScopeStack;
    public String childClassName;

    public int heapOffset = 0;

    public SymTable() {
        mScopeStack = new Stack<Scope>();
        mExpType = new HashMap<Node, Type>();
        main = new MainScope();
        mScopeStack.push(main);
    }
    public void print() {
        System.out.println(main);
    }
    public void outputDot(PrintStream stream) {
        stream.println(main);
    }

    public void printStack() {
        Stack<Scope> copy = (Stack<Scope>) mScopeStack.clone();
        while (!copy.empty()) {
            System.out.println(copy.pop().name);
        }
    }
    public STE lookupSymbol(String sym) {
        Stack<Scope> clone = (Stack<Scope>) this.mScopeStack.clone();
        Scope currentScope = clone.pop();
        STE result = currentScope.lookupSymbol(sym);
        while (result == null) {
            if (clone.empty())
                return null;
            currentScope = clone.pop();
            result = currentScope.lookupSymbol(sym);
        }
        return result;
    }

    public STE lookupInnermostSymbol(String sym) {
        Scope currentScope = mScopeStack.peek();
        return currentScope.lookupSymbol(sym);
    }
    public ClassSTE lookupClass(String sym) {
        return main.lookupClass(sym);
    }
    public MemberVarSTE lookupMemberVar(String sym) {
        MemberVarSTE ret;
        Scope currentScope = mScopeStack.pop();
        if (currentScope instanceof MethodScope)  {
            ret = ((ClassScope)mScopeStack.peek()).lookupMemberVar(sym);
        }
        else {
            ret = ((ClassScope)mScopeStack.peek()).lookupMemberVar(sym);
        }
        mScopeStack.push(currentScope);
        return ret;
    }

    public MethodSTE lookupMethod(String sym) {
        ClassScope currentScope = (ClassScope) mScopeStack.peek();
        return currentScope.lookupMethod(sym);
    }

    public FormalSTE lookupFormal(String sym) {
        MethodScope currentScope = (MethodScope) mScopeStack.peek();
        return currentScope.lookupFormal(sym);
    }

    public LocalVarSTE lookupLocalVar(String sym) {
        MethodScope currentScope = (MethodScope) mScopeStack.peek();
        return currentScope.lookupLocalVar(sym);
    }

    public VarSTE lookupVar(String sym) {
        VarSTE ret = lookupLocalVar(sym);
        if (ret == null) ret = lookupFormal(sym);
        if (ret == null) ret = lookupMemberVar(sym);
        return ret;
    }
    public boolean varIsLocal(String sym) {
        return (lookupLocalVar(sym) != null || lookupFormal(sym) != null);
    }

    public Type getIDType(Node node) {
		IType t = node.getType();
		if (t instanceof IntType) return Type.INT;
		else if (t instanceof ByteType) return Type.BYTE;
		else if (t instanceof ColorType) return Type.COLOR;
		else if (t instanceof BoolType) return Type.BOOL;
		else if (t instanceof VoidType) return Type.VOID;
        	else if (t instanceof ToneType) return Type.TONE;
		else if (t instanceof ClassType) {
            ClassType type = (ClassType) t;
			ClassSTE c = lookupClass(type.getName()); 
			if (c == null) throw new SemanticException("Class " + type.getName() + " undeclared.", t.getLine(), t.getPos());
			return c.type;
		}
		else return null;
    }
        public void insertClass(TopClassDecl node) {
            MainScope top = (MainScope) mScopeStack.peek();
            top.addClass(node);
        }
    
    public void insertMemberVar(VarDecl node) {
        Type type = getIDType(node);
        ClassScope top = (ClassScope) mScopeStack.peek();
        MemberVarSTE newSTE = new MemberVarSTE(node, top.offsetCount, type);
        if (node.getType() instanceof ClassType) newSTE.classTypeName = ((ClassType)node.getType()).getName();
		top.symbols.put(newSTE.name, newSTE);
		top.vars.put(newSTE.name, newSTE);
		top.offsetCount += type.getAVRTypeSize();
    }

    public void insertMethod(MethodDecl node) {
        ClassScope top = (ClassScope) mScopeStack.peek();
        MethodSTE newSTE = new MethodSTE(node, getIDType(node));
        top.symbols.put(node.getName(), newSTE);
        top.methods.put(node.getName(), newSTE);
    }
    public void insertLocalVar(VarDecl node) {
        Type type = getIDType(node);
        MethodScope top = (MethodScope)mScopeStack.peek();
        LocalVarSTE newSTE = new LocalVarSTE(node, top.offsetCount, type);
        if (node.getType() instanceof ClassType) newSTE.classTypeName = ((ClassType)node.getType()).getName();
		top.symbols.put(node.getName(), newSTE);
		top.locals.put(node.getName(), newSTE);
		top.offsetCount += type.getAVRTypeSize();
    }
    public void insertFormal(Formal node) {
        Type type = getIDType(node);
        MethodScope top = (MethodScope) mScopeStack.peek();
        FormalSTE newSTE = new FormalSTE(node, top.offsetCount, type);
		top.symbols.put(node.getName(), newSTE);
		top.formals.put(node.getName(), newSTE);
		top.offsetCount += type.getAVRTypeSize();
    }

    public void pushClassScope(String id) {
        ClassSTE ste = lookupClass(id);
        if (ste == null) {
            System.err.println("Class " + id + " undefined.");
            System.exit(1);
        }
        this.mScopeStack.push(ste.scope);
    }

    public void pushMethodScope(String id) {
        MethodSTE ste = lookupMethod(id);
        if (ste == null) {
            System.err.println("Method " + id + " undefined for class " + mScopeStack.peek().name + ".");
            System.exit(1);
        }
        this.mScopeStack.push(ste.scope);
    }

    public void popScope() {
        this.mScopeStack.pop();
    }
    public void setExpType(Node exp, Type t)
    {
        this.mExpType.put(exp, t);
    }

    public Type getExpType(Node exp)
    {
        return this.mExpType.get(exp);
    }

}
